# Projeto de Sistemas Distribuídos 2015-2016 #

Grupo de SD 46 - Campus Taguspark

81950	João Freitas	joaotavaresfreitas@hotmail.com 
81977	Hugo Gaspar		hugomcgaspar@gmail.com
82528	João Costa		joaocarlos95@gmail.com


Repositório:
[tecnico-distsys/C_XX-project](https://github.com/tecnico-distsys/C_XX-project/) ################################################

-------------------------------------------------------------------------------

## Instruções de instalação 


### Ambiente

[0] Iniciar sistema operativo

Linux


[1] Iniciar servidores de apoio 

JUDDI:
```
Servidor de nomes para Web Services - jUDDI 3.3.2, configurado para a porta 9090
Tornar executáveis os scripts de lançamento - chmod +x juddi-3.3.2_tomcat-7.0.64_9090/bin/*.sh
Executar o comando ./startup.sh na pasta juddi-3.3.2_tomcat-7.0.64_9090/bin para lançar o servidor
Confirmar o funcionamento so servidor, acedendo à página http://localhost:9090/juddiv3/
Introduzir as credenciais: utilizador: uddiadmin e senha: da_password1
```


[2] Criar pasta temporária

```
cd Documents
mkdir ProjectoSD
```


[3] Obter código fonte do projeto (versão entregue)

```
Ir ao Fénix e transferir o ficheiro.
Descomprimir os ficheiros dessa pasta para a pasta ProjectoSD.
```


[4] Instalar módulos de bibliotecas auxiliares

```
cd uddi-naming
mvn clean install
```


-------------------------------------------------------------------------------

### Serviço TRANSPORTER

[1] Construir e executar **servidor**

```
1º Terminal
____________________________________
cd Desktop/ProjectoSD/transporter-ws
mvn clean install && mvn generate-sources
mvn compile exec:java

2º Terminal
____________________________________
cd Desktop/ProjectoSD/transporter-ws
mvn clean install && mvn generate-sources
mvn compile -Dws.i=2 exec:java
```

[2] Construir **cliente** e executar testes

```
cd Desktop/ProjectoSD/transporter-ws-cli
mvn clean install && mvn generate-sources
mvn compile
mvn verify

cd Desktop/ProjectoSD/transporter-ws
mvn clean install && mvn generate-sources
mvn compile
mvn test
```

...


-------------------------------------------------------------------------------

### Serviço BROKER

[1] Construir e executar **servidor**

```
cd Desktop/ProjectoSD/broker-ws
mvn clean install && mvn generate-sources
mvn compile
mvn exec:java
```


[2] Construir **cliente** e executar testes

```
cd Desktop/ProjectoSD/broker-ws-cli
mvn clean install && mvn generate-sources
mvn compile
mvn verify

cd Desktop/ProjectoSD/broker-ws
mvn clean install && mvn generate-sources
mvn compile
mvn test
```

...

-------------------------------------------------------------------------------
**FIM**
