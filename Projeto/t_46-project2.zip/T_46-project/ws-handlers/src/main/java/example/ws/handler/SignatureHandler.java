package example.ws.handler;

import static javax.xml.bind.DatatypeConverter.parseBase64Binary;
import static javax.xml.bind.DatatypeConverter.printBase64Binary;
import static javax.xml.bind.DatatypeConverter.printHexBinary;
import static javax.xml.ws.BindingProvider.ENDPOINT_ADDRESS_PROPERTY;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.xml.namespace.QName;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import pt.ulisboa.tecnico.sdis.ws.uddi.UDDINaming;
import pt.upa.ca.ws.Ca;
import pt.upa.ca.ws.CaImplService;



/**
 *  This SOAPHandler shows how to set/get values from headers in
 *  inbound/outbound SOAP messages.
 *
 *  A header is created in an outbound message and is read on an
 *  inbound message.
 *
 *  The value that is read from the header
 *  is placed in a SOAP message context property
 *  that can be accessed by other handlers or by the application.
 */
public class SignatureHandler implements SOAPHandler<SOAPMessageContext> {
	
	public static String SENDER_NAME = null;
	
	final static String KEY_PASSWORD = "1nsecure";
	final static String KEYSTORE_PASSWORD = "ins3cur3";
	
	public static final String REQUEST_PROPERTY = "my.request.property";
	
	public static final String REQUEST_HEADER = "myRequestHeader";
	public static final String REQUEST_NS = "urn:example";

	final static String CA_CERTIFICATE_FILE = "ca-certificate.pem.txt";
	//a mudar !!!!!!!!!!!!!!!!!!!!!
	public String KEYSTORE_FILE = SENDER_NAME + ".jks";
	public String KEY_ALIAS = SENDER_NAME;
	
	private HashMap<String, Certificate> certs = new HashMap<String, Certificate>();
	private List<String> listIDs = new ArrayList<String>();
	

    //
    // Handler interface methods
    //
    public Set<QName> getHeaders() {
        return null;
    }

    public boolean handleMessage(SOAPMessageContext smc) {
        System.out.println("AddHeaderHandler: Handling message.");

        Boolean outboundElement = (Boolean) smc
                .get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

        try {
            if (outboundElement.booleanValue()) { //Outbound message
            	
            	String propertyValue = (String) smc.get(REQUEST_PROPERTY);
            	propertyValue = SENDER_NAME;
                UUID id = UUID.randomUUID();
                
            	SOAPMessage msg = smc.getMessage();
				SOAPPart sp = msg.getSOAPPart();
				SOAPEnvelope se = sp.getEnvelope();
				 
				SOAPBody mb = se.getBody();
				if (mb == null) {
					System.out.println("Body not found.");
					return false;
				}
				
                String messageBody = mb.toString();
                byte[] plainBytes = messageBody.getBytes();

                /*System.out.println("Text:");
                System.out.println(messageBody);

                System.out.println("Bytes:");
                System.out.println(printHexBinary(plainBytes));*/
                
                
                // make digital signature
                System.out.println("Signing ...");
                byte[] digitalSignature = makeDigitalSignature(plainBytes, getPrivateKeyFromKeystore(KEYSTORE_FILE,
                        KEYSTORE_PASSWORD.toCharArray(), KEY_ALIAS, KEY_PASSWORD.toCharArray()));

                /*System.out.println("Signature Bytes:");
                System.out.println(printHexBinary(digitalSignature));*/
                
                //add header
                SOAPHeader sh = se.getHeader();
                if (sh == null)
                    sh = se.addHeader();
                
                
                // add header assinatura digital (name, namespace prefix, namespace)
                Name name = se.createName("myHeader", "d", "http://demo");
                SOAPHeaderElement element = sh.addHeaderElement(name);
                String valueString = printBase64Binary(digitalSignature);
                element.addTextNode(valueString);
                
                
                // add header nome entidade
                name = se.createName(REQUEST_HEADER, "e", REQUEST_NS);
				element = sh.addHeaderElement(name);
				element.addTextNode(propertyValue);
                
				
				// add header id
                name = se.createName("myID", "e", "http://demo");
				element = sh.addHeaderElement(name);
				element.addTextNode(id.toString());
				
				//make signature id
				byte[] plainId = id.toString().getBytes();
				byte[] digitalSignature1 = makeDigitalSignature(plainId, getPrivateKeyFromKeystore(KEYSTORE_FILE,
                        KEYSTORE_PASSWORD.toCharArray(), KEY_ALIAS, KEY_PASSWORD.toCharArray()));
				
				// add header assinatura id
                name = se.createName("myHeader1", "d", "http://demo");
                element = sh.addHeaderElement(name);
                valueString = printBase64Binary(digitalSignature1);
                element.addTextNode(valueString);
			
                
            } else { //Inbound message
            	
            	SOAPMessage msg = smc.getMessage();
				SOAPPart sp = msg.getSOAPPart();
				SOAPEnvelope se = sp.getEnvelope();
				 
				SOAPBody mb = se.getBody();
				if (mb == null) {
					System.out.println("Body not found.");
					return false;
				}
				
				SOAPHeader sh = se.getHeader();

                // check header
                if (sh == null) {
                    System.out.println("Header not found.");
                    return false;
                }
                
                Name name = se.createName("myHeader", "d", "http://demo");
                Iterator it = sh.getChildElements(name);
                
                // check header element
                if (!it.hasNext()) {
                    System.out.println("Header element not found.");
                    return false;
                }
                
                SOAPElement element = (SOAPElement) it.next();
				String valueString = element.getValue();
				
				byte[] digitalSignature = parseBase64Binary(valueString);
				
                String messageBody = mb.toString();
                byte[] plainBytes = messageBody.getBytes();
                /*System.out.println("Text:");
                System.out.println(messageBody);

                System.out.println("Bytes:");
                System.out.println(printHexBinary(plainBytes));*/
                
                //Buscar assinatura do id
                name = se.createName("myHeader1", "d", "http://demo");
                it = sh.getChildElements(name);
                
                // check header element
                if (!it.hasNext()) {
                    System.out.println("Header element not found.");
                    return false;
                }
                
                element = (SOAPElement) it.next();
				valueString = element.getValue();
				byte[] digitalSignature1 = parseBase64Binary(valueString);
				
				
        		name = se.createName(REQUEST_HEADER, "e", REQUEST_NS);
				it = sh.getChildElements(name);
				// check header element
				if (!it.hasNext()) {
					System.out.printf("Header element %s not found.%n", REQUEST_HEADER);
					return false;
				}
				element = (SOAPElement) it.next();

				// *** #10 ***
				// get header element value
				String headerValue1 = element.getValue();
				System.out.printf("got '%s'%n", headerValue1);
				
                name = se.createName("myID", "e", "http://demo");
				it = sh.getChildElements(name);
				// check header element
				if (!it.hasNext()) {
					System.out.printf("Header element %s not found.%n", "myID");
					return false;
				}
				element = (SOAPElement) it.next();
				String headerValue4 = element.getValue();
				if (Arrays.asList(listIDs).contains(headerValue4) == false) {
					listIDs.add(headerValue4);
				}
				else {
					throw new RuntimeException();
				}
				
				Certificate certificate = null;
				if(certs.get(headerValue1) == null){
					
		            String uddiURL2 ="http://localhost:9090";
		    		String name3 = "Ca";
		    		UDDINaming uddiNaming = null;		
	    			
	       			System.out.printf("Contacting UDDI at %s%n", uddiURL2);
	    			uddiNaming = new UDDINaming(uddiURL2);
	
	    			System.out.printf("Looking for '%s'%n", name3);
	    			String endpointAddress2 = uddiNaming.lookup(name3);
	
	    			if (endpointAddress2 == null) {
	    				System.out.println("Not found!");
	    				return true;
	    			} else {
	    				System.out.printf("Found %s%n", endpointAddress2);
	    			}
	
	    			System.out.println("Creating stub ...");
	    			CaImplService service3 = new CaImplService();
	    			Ca port3 = service3.getCaImplPort();
	
	    			System.out.println("Setting endpoint address ...");
	    			BindingProvider bindingProvider2 = (BindingProvider) port3;
	    			Map<String, Object> requestContext2 = bindingProvider2.getRequestContext();
	    			requestContext2.put(ENDPOINT_ADDRESS_PROPERTY, endpointAddress2);
	        		
	
	        		ByteArrayInputStream bis = new ByteArrayInputStream(port3.getCertificates(headerValue1));
	        		ObjectInput in = null;
	        		in = new ObjectInputStream(bis);
	        		certificate = (Certificate) in.readObject();
	        		//System.out.println(certificate);
	        		
	        		Certificate caCertificate = readCertificateFile(CA_CERTIFICATE_FILE);
	        		PublicKey caPublicKey = caCertificate.getPublicKey();
	
	        		if (verifySignedCertificate(certificate, caPublicKey)) {
	        			System.out.println("The signed certificate is valid");
	        			certs.put(headerValue1, certificate);
	        		} else {
	        			System.err.println("The signed certificate is not valid");
	        			throw new RuntimeException();
	        		}
				}
				else{
					certificate = certs.get(headerValue1);
				}
        		
                PublicKey publicKey = certificate.getPublicKey();

                // verify the digital signature
                System.out.println("Verifying ...");
               
                boolean isValid = verifyDigitalSignature(digitalSignature, plainBytes, publicKey);
                boolean isValid1 = verifyDigitalSignature(digitalSignature1, headerValue4.getBytes(), publicKey);

                if (isValid) {
                    System.out.println("The digital signature is valid");
                } else {
                    System.out.println("The digital signature is NOT valid");
                    throw new RuntimeException();
                }
                if (isValid1) {
                    System.out.println("The digital signature of the id is valid");
                } else {
                    System.out.println("The digital signature of the id is NOT valid");
                    throw new RuntimeException();
                }

            }
        } catch (Exception e) {
            System.out.print("Caught exception in handleMessage: ");
            System.out.println(e);
            System.out.println("Continue normal processing...");
        }

        return true;
    }

    public boolean handleFault(SOAPMessageContext smc) {
        System.out.println("Ignoring fault message...");
        return true;
    }

    public void close(MessageContext messageContext) {
    }

    /**
     * Reads a certificate from a file
     * 
     * @return
     * @throws Exception
     */
    public static Certificate readCertificateFile(String certificateFilePath) throws Exception {
        FileInputStream fis;

        try {
            fis = new FileInputStream(certificateFilePath);
        } catch (FileNotFoundException e) {
            System.err.println("Certificate file <" + certificateFilePath + "> not found.");
            return null;
        }
        BufferedInputStream bis = new BufferedInputStream(fis);

        CertificateFactory cf = CertificateFactory.getInstance("X.509");

        if (bis.available() > 0) {
            Certificate cert = cf.generateCertificate(bis);
            return cert;
            // It is possible to print the content of the certificate file:
            // System.out.println(cert.toString());
        }
        bis.close();
        fis.close();
        return null;
    }

    /**
     * Verifica se um certificado foi devidamente assinado pela CA
     * 
     * @param certificate
     *            certificado a ser verificado
     * @param caPublicKey
     *            certificado da CA
     * @return true se foi devidamente assinado
     */
    public static boolean verifySignedCertificate(Certificate certificate, PublicKey caPublicKey) {
        try {
            certificate.verify(caPublicKey);
        } catch (InvalidKeyException | CertificateException | NoSuchAlgorithmException | NoSuchProviderException
                | SignatureException e) {
            // O método Certifecate.verify() não retorna qualquer valor (void).
            // Quando um certificado é inválido, isto é, não foi devidamente
            // assinado pela CA
            // é lançada uma excepção: java.security.SignatureException:
            // Signature does not match.
            // também são lançadas excepções caso o certificado esteja num
            // formato incorrecto ou tenha uma
            // chave inválida.

            return false;
        }
        return true;
    }

    /**
     * Returns the public key from a certificate
     * 
     * @param certificate
     * @return
     */
    public static PublicKey getPublicKeyFromCertificate(Certificate certificate) {
        return certificate.getPublicKey();
    }

    /**
     * Reads a collections of certificates from a file
     * 
     * @return
     * @throws Exception
     */
    public static Collection<Certificate> readCertificateList(String certificateFilePath) throws Exception {
        FileInputStream fis;

        try {
            fis = new FileInputStream(certificateFilePath);
        } catch (FileNotFoundException e) {
            System.err.println("Certificate file <" + certificateFilePath + "> not fount.");
            return null;
        }
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        @SuppressWarnings("unchecked")
        Collection<Certificate> c = (Collection<Certificate>) cf.generateCertificates(fis);
        fis.close();
        return c;

    }

    /**
     * Reads a PrivateKey from a key-store
     * 
     * @return The PrivateKey
     * @throws Exception
     */
    public static PrivateKey getPrivateKeyFromKeystore(String keyStoreFilePath, char[] keyStorePassword,
            String keyAlias, char[] keyPassword) throws Exception {

        KeyStore keystore = readKeystoreFile(keyStoreFilePath, keyStorePassword);
        PrivateKey key = (PrivateKey) keystore.getKey(keyAlias, keyPassword);

        return key;
    }

    /**
     * Reads a KeyStore from a file
     * 
     * @return The read KeyStore
     * @throws Exception
     */
    public static KeyStore readKeystoreFile(String keyStoreFilePath, char[] keyStorePassword) throws Exception {
        FileInputStream fis;
        try {
            fis = new FileInputStream(keyStoreFilePath);
        } catch (FileNotFoundException e) {
            System.err.println("Keystore file <" + keyStoreFilePath + "> not fount.");
            return null;
        }
        KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
        keystore.load(fis, keyStorePassword);
        return keystore;
    }

    /** auxiliary method to calculate digest from text and cipher it */
    public static byte[] makeDigitalSignature(byte[] bytes, PrivateKey privateKey) throws Exception {

        // get a signature object using the SHA-1 and RSA combo
        // and sign the plain-text with the private key
        Signature sig = Signature.getInstance("SHA1WithRSA");
        sig.initSign(privateKey);
        sig.update(bytes);
        byte[] signature = sig.sign();

        return signature;
    }

    /**
     * auxiliary method to calculate new digest from text and compare it to the
     * to deciphered digest
     */
    public static boolean verifyDigitalSignature(byte[] cipherDigest, byte[] bytes, PublicKey publicKey)
            throws Exception {

        // verify the signature with the public key
        Signature sig = Signature.getInstance("SHA1WithRSA");
        sig.initVerify(publicKey);
        sig.update(bytes);
        try {
            return sig.verify(cipherDigest);
        } catch (SignatureException se) {
            System.err.println("Caught exception while verifying signature " + se);
            return false;
        }
    }

}